// Validates the generalized Range<a,b>::Part::run_n (SIMD) against the plain
// chk()-loop it replaces, using a mock Base that mimics oneOutput::OutAPI's
// put() contract (CRTP Part<O> : O pattern, same as the real oneParse.h).

#include <cstdio>
#include <cstring>
#include <string>
#include <random>
#include <chrono>
#if defined(__SSE2__) || defined(__AVX2__)
#include <immintrin.h>
#endif

using Src = const char*;
enum class St : uint8_t { ok, partial, fail };
struct StreamRes {
  St state; char val{0};
  static constexpr StreamRes Ok(char c){return{St::ok,c};}
  static constexpr StreamRes Fail(){return{St::fail,0};}
};

// ── minimal mock of oneOutput::OutAPI<Cfg> ──────────────────────────────────
struct MockBase {
  std::string out;
  void put(char c) { out.push_back(c); }
};

// ── Range<a,b> exactly as proposed for oneParse.h ───────────────────────────
template<char a, char b>
struct Range {
  static_assert(a <= b, "Range<a,b>: requires a<=b -- the SIMD run_n wraparound "
                         "trick (span=b-a as unsigned) is only valid for a proper "
                         "ascending range; an inverted range silently matches "
                         "everything instead of nothing under that trick.");
  template<typename O> struct Part : O {
    using Base = O; using Base::Base; using Base::put;
    static constexpr bool chk(char c) { return a<=c && c<=b; }

    StreamRes run(char c) {
      if (chk(c)) { put(c); return StreamRes::Ok(c); }
      return StreamRes::Fail();
    }

#if !defined(ONE_PARSE_RANGE_TIGHT_LOOP) && (defined(__SSE2__) || defined(__AVX2__))
    // Branchless unsigned range test: (c - a) as uint8 wraps correctly for c < a;
    // subs_epu8(t, b-a) == 0 iff (c-a) <= (b-a) unsigned, i.e. a<=c<=b.
    // Each stage's for-loop only enters when a full vector remains in [s, s+n) --
    // no over-read; falls through to a narrower stage, then the scalar tail.
    size_t run_n(const char* s, size_t n) {
      size_t i = 0;
      constexpr unsigned char lo   = (unsigned char)a;
      constexpr unsigned char span = (unsigned char)(b - a);
#if defined(__AVX2__)
      {
        const __m256i vlo   = _mm256_set1_epi8((char)lo);
        const __m256i vspan = _mm256_set1_epi8((char)span);
        for (; i + 32 <= n; i += 32) {
          __m256i v    = _mm256_loadu_si256((const __m256i*)(s + i));
          __m256i t    = _mm256_sub_epi8(v, vlo);
          __m256i diff = _mm256_subs_epu8(t, vspan);
          unsigned mask = (unsigned)_mm256_movemask_epi8(
                             _mm256_cmpeq_epi8(diff, _mm256_setzero_si256()));
          if (mask != 0xFFFFFFFFu) {
            unsigned run = (unsigned)__builtin_ctz(~mask);
            for (unsigned k = 0; k < run; ++k) put(s[i+k]);
            return i + run;
          }
          for (unsigned k = 0; k < 32; ++k) put(s[i+k]);
        }
      }
#endif
#if defined(__SSE2__)
      {
        const __m128i vlo   = _mm_set1_epi8((char)lo);
        const __m128i vspan = _mm_set1_epi8((char)span);
        for (; i + 16 <= n; i += 16) {
          __m128i v    = _mm_loadu_si128((const __m128i*)(s + i));
          __m128i t    = _mm_sub_epi8(v, vlo);
          __m128i diff = _mm_subs_epu8(t, vspan);
          unsigned mask = (unsigned)_mm_movemask_epi8(
                             _mm_cmpeq_epi8(diff, _mm_setzero_si128())) & 0xFFFFu;
          if (mask != 0xFFFFu) {
            unsigned run = (unsigned)__builtin_ctz((~mask) & 0xFFFFu);
            for (unsigned k = 0; k < run; ++k) put(s[i+k]);
            return i + run;
          }
          for (unsigned k = 0; k < 16; ++k) put(s[i+k]);
        }
      }
#endif
      while (i < n && chk(s[i])) { put(s[i]); ++i; }
      return i;
    }
#else
    // MCU / no-SIMD-ISA path: identical to today's tight loop. __SSE2__/__AVX2__
    // are only ever defined by the compiler when the target actually has that
    // ISA, so AVR-GCC / arm-none-eabi-gcc never see the block above at all --
    // not even as dead code to size-check.
    size_t run_n(const char* s, size_t n) {
      size_t i = 0;
      while (i < n && chk(s[i])) { put(s[i]); ++i; }
      return i;
    }
#endif
  };
  static constexpr bool chk(char c) { return a<=c && c<=b; }
};

// ── reference (tight-loop) impl for correctness comparison ─────────────────
template<char a, char b>
size_t ref_run_n(const char* s, size_t n, std::string& out) {
  size_t i = 0;
  while (i < n && a<=s[i] && s[i]<=b) { out.push_back(s[i]); ++i; }
  return i;
}

template<char a, char b>
bool verify() {
  std::mt19937 rng(1234);
  for (int trial = 0; trial < 50000; ++trial) {
    int len = (rng() % 80) + 1;
    std::string s;
    for (int i = 0; i < len; ++i) s.push_back(char(rng() % 256));
    // start position varies to exercise all alignment/tail combinations
    int start = rng() % (len);
    std::string sub = s.substr(start);

    std::string expOut; size_t exp = ref_run_n<a,b>(sub.c_str(), sub.size(), expOut);

    typename Range<a,b>::template Part<MockBase> p{};
    size_t got = p.run_n(sub.c_str(), sub.size());

    if (got != exp || p.out != expOut) {
      printf("MISMATCH a=%d b=%d len=%zu start=%d exp=%zu got=%zu\n",
             a, b, sub.size(), start, exp, got);
      printf("  input: "); for (unsigned char c: sub) printf("%02x ", c); printf("\n");
      return false;
    }
  }
  return true;
}

int main() {
  bool ok = true;
  ok &= verify<'0','9'>();   // digits (Range's most common real use)
  ok &= verify<'a','z'>();   // lowercase alpha
  ok &= verify<0,0>();       // degenerate: a==b
  ok &= verify<(char)-128,(char)127>(); // full valid range (CHAR_MIN..CHAR_MAX), span=255 edge
  printf("verify all: %s\n\n", ok ? "OK" : "FAILED");

  // quick perf sanity vs the earlier standalone bench, now through the real Part<O> path
  std::mt19937 rng(7);
  std::string buf; std::vector<size_t> offsets;
  buf.reserve(1<<20);
  while (buf.size() < (1u<<20)) {
    offsets.push_back(buf.size());
    int w = (rng()%12)+1;
    for (int i=0;i<w;++i) buf.push_back(char('0'+(rng()%10)));
    buf += ",\"k\":";
  }
  using Clock = std::chrono::steady_clock;
  auto t0 = Clock::now();
  volatile size_t sink=0;
  for (int r=0;r<50;++r) {
    typename Range<'0','9'>::template Part<MockBase> p{};
    p.out.reserve(1<<16);
    for (size_t off: offsets) { p.out.clear(); sink += p.run_n(buf.c_str()+off, buf.size()-off); }
  }
  auto t1 = Clock::now();
  double ns_per_call = std::chrono::duration<double>(t1-t0).count()*1e9/(offsets.size()*50);
  printf("through real Part<O>::run_n (with put() per matched byte): %.1f ns/call (sink=%zu)\n",
         ns_per_call, sink);
  return ok ? 0 : 1;
}
