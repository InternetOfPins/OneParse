# Handoff: SIMD run_n for oneParse::Range<a,b>

## Context
Prototyped and validated a SIMD bulk-scan `run_n` for `Range<a,b>::Part` in
oneParse.h. Done against a mock harness (no access to the real oneOutput.h /
hapi.h headers) — needs a pass against the real files before merging.

## What was benchmarked (x86-64, -O3 -march=native, this machine)
- Long homogeneous digit run (1MB): SSE2 7.8x, AVX2 14.1x over scalar chk() loop.
- Realistic short JSON number fields (~1-12 digits, real call pattern —
  offset into a shared buffer, not isolated buffers): SSE2 5.5x, AVX2 5.3x
  (AVX2 buys nothing extra here — 32B width wasted on short fields).
- Isolated single-field calls (cold, no amortization): SSE2 still wins (1.98
  vs 1.36 GB/s), AVX2 loses to scalar (setup cost with n<32 always).
- **Through the real Part<O> CRTP shape with put() called per matched byte:
  24.1 ns/call, vs ~2.6 ns/call for the bare SIMD scan alone.** put() (one
  std::string::push_back-equivalent per byte) dominates once the scan itself
  is cheap — same bottleneck String::run_n already has. This is the next
  real lever, not more SIMD. **Check whether oneOutput::OutAPI has, or could
  get, a bulk `put(const char*, size_t)` — that's the highest-value follow-up.**

## Correctness
Fuzzed 50k random cases per range (digits, alpha, degenerate a==b, full valid
range CHAR_MIN..CHAR_MAX) at randomized lengths/start offsets to hit every
SIMD alignment/tail boundary. All pass. One real edge case found and fixed:
the wraparound trick (span = b-a as unsigned) silently matches *everything*
instead of *nothing* if a>b (inverted range) — added a static_assert(a<=b)
precondition since chk() itself already implicitly assumes ascending a,b.

Loop bounds (`i + WIDTH <= n`) guard against over-reading past the buffer —
confirmed no out-of-bounds access via the fuzzed start-offset tests.

## MCU safety
`__SSE2__`/`__AVX2__` are only defined by the compiler when the target ISA
actually has them — AVR-GCC / arm-none-eabi-gcc never define these, so the
SIMD block is invisible on MCU builds, not even present as dead code. Falls
through to `#else`, which is byte-for-byte identical to the current tight
loop. No flash/size impact on MCU targets. Consistent with the existing
`ONE_PARSE_STRING_TIGHT_LOOP` escape hatch pattern already used in String.

## Files
- `handoff_test.cpp` (attached) — full mock harness + verify() + perf check.
  Ready to run as-is: `g++ -O3 -march=native -std=c++17 handoff_test.cpp -o t && ./t`

## TODO before merging into oneParse.h
1. Compare mock `MockBase::put(char)` against the real `oneOutput::OutAPI<Cfg>`
   signature — confirm CRTP shape (`using Base::put`) matches exactly.
2. Check for an existing bulk put(ptr,len) on OutAPI; if present, replace the
   per-byte `for (k…) put(s[i+k])` loops in the SIMD path with one bulk call —
   should close most of the 2.6ns → 24.1ns gap.
3. Drop the validated `Range<a,b>::Part::run_n` into oneParse.h, gated exactly
   as shown (SSE2/AVX2 `#if`, `ONE_PARSE_RANGE_TIGHT_LOOP` escape hatch mirroring
   String's convention).
4. Re-run against real oneParse benchmark corpus (JSON payloads), not synthetic
   digit fields, to confirm the field-width-distribution assumption holds.
5. Add `handoff_test.cpp`'s fuzzed verify() (or fold into existing test suite)
   as a permanent regression check — the a<=b edge case is exactly the kind of
   thing that passes normal digit/alpha tests and only shows up under fuzzing.
